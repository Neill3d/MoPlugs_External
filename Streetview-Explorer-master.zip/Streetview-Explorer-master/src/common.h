#ifndef COMMON_H
#define	COMMON_H

#define PI 3.1415f
#define TWICE_PI (2*PI)
extern const float RADIAL;

#endif	/* COMMON_H */


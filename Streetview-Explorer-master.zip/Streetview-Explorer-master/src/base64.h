#ifndef BASE64_H
#define BASE64_H

int decode_base64(unsigned char *dest, const char *src);

#endif /* BASE64_H */

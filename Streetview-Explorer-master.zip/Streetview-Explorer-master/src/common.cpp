#include "common.h"

const float RADIAL = 1 / (float) 360 * TWICE_PI;
